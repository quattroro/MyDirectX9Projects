#include "pch.h"
#include "Multiply.h"
extern "C" _declspec(dllexport)
int Multiply(int a, int b)
{
	return a * b;
}

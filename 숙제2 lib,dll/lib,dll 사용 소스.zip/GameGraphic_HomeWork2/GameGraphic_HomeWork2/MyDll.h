#pragma once

extern "C" _declspec(dllimport)
int Multiply(int, int);
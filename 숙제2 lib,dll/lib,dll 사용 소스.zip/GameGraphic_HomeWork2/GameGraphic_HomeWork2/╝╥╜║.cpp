#include <Windows.h>
#include <iostream>

//#pragma comment(lib,"MyDll.lib")
#include "MyDll.h"

#pragma comment(lib,"MyLib.lib")
#include "MyLib.h"



using namespace std;

void main()
{
	HMODULE hdll = LoadLibraryA("MyDll.dll");
	int (*FuntionPointer)(int, int) = NULL;
	FuntionPointer = (int(*)(int, int))GetProcAddress(hdll, "Multiply");
	cout << FuntionPointer(3, 4);
	FreeLibrary(hdll);

	//cout << Multiply(4, 5);
	cout << endl << Add(3, 4);
}
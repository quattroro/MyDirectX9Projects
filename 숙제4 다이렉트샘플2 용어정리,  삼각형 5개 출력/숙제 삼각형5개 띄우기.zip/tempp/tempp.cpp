﻿//-----------------------------------------------------------------------------
// File: Vertices.cpp
//
// Desc: In this tutorial, we are rendering some vertices. This introduces the
//       concept of the vertex buffer, a Direct3D object used to store
//       vertices. Vertices can be defined any way we want by defining a
//       custom structure and a custom FVF (flexible vertex format). In this
//       tutorial, we are using vertices that are transformed (meaning they
//       are already in 2D window coordinates) and lit (meaning we are not
//       using Direct3D lighting, but are supplying our own colors).
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------

#pragma comment(lib,"d3d9.lib")
#include <d3d9.h>
#pragma warning( disable : 4996 ) // disable deprecated warning 
#include <strsafe.h>
#pragma warning( default : 4996 )




//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
LPDIRECT3D9             g_pD3D = NULL; // 디바이스를 생성하기 위한 헬퍼(공장)
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL; // 다이렉트X의 핵심 (가상장치)
LPDIRECT3DVERTEXBUFFER9 g_pVB = NULL; // 정점버퍼 구조체의 포인터


//미리 지정된 폼 안에서 사용자가 사용할 정점을 커스텀 할 수 있다.
struct CUSTOMVERTEX
{
    FLOAT x, y, z, rhw; // The transformed position for the vertex
    DWORD color;        // The vertex color
};

// Our custom FVF, which describes our custom vertex structure
//이것도 중요!! 내가 만든 정점의 정보의 순서와 같은 순서로 선언 해줘야 한다.!!!!
//사용자가 만든 커스텀정점이 각각이 어떤 의미인지 알게 해주기 위해 해준다.
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZRHW|D3DFVF_DIFFUSE)




//-----------------------------------------------------------------------------
// Name: InitD3D()
// Desc: Initializes Direct3D
//-----------------------------------------------------------------------------
HRESULT InitD3D(HWND hWnd)
{
    // Create the D3D object.
    if (NULL == (g_pD3D = Direct3DCreate9(D3D_SDK_VERSION)))//디바이스를 생성하지 위한 공장을 생성
        return E_FAIL;

    // Set up the structure used to create the D3DDevice
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory(&d3dpp, sizeof(d3dpp));
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;

    // 디바이스를 생성할때 윈도우 핸들이 필요하도록 되어 있다. 때문에 초기화를 하기 전에 윈도우를 먼저 만들어 준다.
    if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &g_pd3dDevice)))
    {
        return E_FAIL;
    }

    // Device state would normally be set here

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitVB()
// Desc: Creates a vertex buffer and fills it with our vertices. The vertex
//       buffer is basically just a chuck of memory that holds vertices. After
//       creating it, we must Lock()/Unlock() it to fill it. For indices, D3D
//       also uses index buffers. The special thing about vertex and index
//       buffers is that they can be created in device memory, allowing some
//       cards to process them in hardware, resulting in a dramatic
//       performance gain.
//-----------------------------------------------------------------------------
HRESULT InitVB()
{
    // Initialize three vertices for rendering a triangle
    //directX는 왼손 좌표계를 사용하기 때문에 정점의 순서는 시계방향으로 입력되어야 한다.
    //
    CUSTOMVERTEX vertices[] =
    {

        { 100.0f,  300.0f, 0.0f, 1.0f, 0x00ff0000, }, // 위 x, y, z, rhw, color
        { 200.0f, 500.0f, 0, 1.0f, 0x0000ff00, },//오른쪽 아래
        {  0.0f, 500.0f, 0, 1.0f, 0x0000ffff, },//왼쪽아래

        { 100.0f,  300.0f, 0.0f, 1.0f, 0x00ff0000, }, //왼쪽 위 x, y, z, rhw, color
        { 300.0f, 300.0f, 0, 1.0f, 0x0000ff00, },//오른쪽 위
        { 200.0f, 500.0f, 0, 1.0f, 0x0000ffff, },//아래

        { 200.0f,  500.0f, 0.0f, 1.0f, 0x00ff0000, }, // 왼쪽아래 x, y, z, rhw, color
        { 300.0f, 300.0f, 0.0f, 1.0f, 0x0000ff00, },// 위
        { 400.0f, 500.0f, 0.0f, 1.0f, 0x0000ffff, },//오른쪽아래

        { 100.0f,  300.0f, 0.0f, 1.0f, 0x0000ffff, }, // 왼쪽아래 x, y, z, rhw, color
        { 200.0f, 100.0f, 0.0f, 1.0f, 0x00ff0000, },// 위
        { 300.0f, 300.0f, 0.0f, 1.0f, 0x0000ff00, },//오른쪽아래

        { 500.0f,  500.0f, 0.0f, 1.0f, 0x0000ffff, }, // 왼쪽아래 x, y, z, rhw, color
        { 800.0f, 100.0f, 0.0f, 1.0f, 0x00ff0000, },// 위
        { 800.0f, 500.0f, 0.0f, 1.0f, 0x0000ff00, },//오른쪽아래
        
    };

    

    // Create the vertex buffer. Here we are allocating enough memory
    // (from the default pool) to hold all our 3 custom vertices. We also
    // specify the FVF, so the vertex buffer knows what data it contains.
    // 
    


    // 정점버퍼 생성 함수
    //생성할 버퍼의 크기
    //버퍼의 종류, 처리방식 0을 지정하면 부가적인 특성 없음
    //FVF플래그값 정점 버퍼에 보관될 FVF
    //버퍼가 저장될 메모리위치(그래픽 카드, 시스템 메모리)
    //반활될 정점버퍼의 인터페이스 반환된 정점 버퍼를 받을 포인터
    //이용되지 않는다. 이 파라미터는 NULL로 설정한다
    if (FAILED(g_pd3dDevice->CreateVertexBuffer(15 * sizeof(CUSTOMVERTEX), 0, D3DFVF_CUSTOMVERTEX, D3DPOOL_DEFAULT, &g_pVB, NULL)))
    {
        return E_FAIL;
    }


    // Now we fill the vertex buffer. To do this, we need to Lock() the VB to
    // gain access to the vertices. This mechanism is required becuase vertex
    // buffers may be in device memory.

    //일단 생성한 정점 버퍼는 쓰레기 값으로 가득 차 있기 때문에 값을 넣어줘야 한다.
    //정점 버퍼에 정점을 입력하기 위해서는 정점 버퍼의 주소값이 필요하다.
    //LOCK 함수를 이용해서 포인터를 얻어온다.
    //Lock을 할 버퍼의 시작점, SizeToLock과 함께 양쪽 모두 0이면 전체 버퍼
    //Lock을 할 바이트의 수, OffsetToLock과 함께 양쪽 모두 0이면 전체 버퍼
    //읽고 쓸 수 있게 된 메모리 영역의 시작을 가리키는 포인터 (VOID* 포인터)
    //Lock이 이루어지는 방법을 지정

    //Lock()을 하게 되면 해당 메모리는 다른 자원에서 접근할 수 없게 되며 정점을 저장하기 위한 메모리 포인터(주소)를 얻게 된다.
    VOID* pVertices;//락을 걸 위치를 알아오기 위함
    if (FAILED(g_pVB->Lock(0, sizeof(vertices), (void**)&pVertices, 0)))
        return E_FAIL;

    memcpy(pVertices, vertices, sizeof(vertices));


    //LOCK을 했으면 반드시 UNLOCK을 해야한다.
    g_pVB->Unlock();
 
    
    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all previously initialized objects
//-----------------------------------------------------------------------------
VOID Cleanup()
{
    /*if (g_pVB2 != NULL)
        g_pVB2->Release();
    if (g_pVB3 != NULL)
        g_pVB3->Release();*/

    if (g_pVB != NULL)
        g_pVB->Release();//정점 버퍼가 디바이스보다 먼저 해제되어야 한다. 디바이스정보로 정점버퍼를 생성한것이기 때문

    if (g_pd3dDevice != NULL)
        g_pd3dDevice->Release();

    if (g_pD3D != NULL)
        g_pD3D->Release();
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID Render()
{
    // Clear the backbuffer to a blue color
    g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0);

    // Begin the scene
    if (SUCCEEDED(g_pd3dDevice->BeginScene()))
    {
        // Draw the triangles in the vertex buffer. This is broken into a few
        // steps. We are passing the vertices down a "stream", so first we need
        // to specify the source of that stream, which is our vertex buffer. Then
        // we need to let D3D know what vertex shader to use. Full, custom vertex
        // shaders are an advanced topic, but in most cases the vertex shader is
        // just the FVF, so that D3D knows what type of vertices we are dealing
        // with. Finally, we call DrawPrimitive() which does the actual rendering
        // of our geometry (in this case, just one triangle).


        //정점을 렌더링하기 위해서는 정점 버퍼와 정점의 포맷을 D3D 디바이스에게 알려주어야 한다.
        //이와 같은 역할을 해주는 함수가 SetStreamSource()이며 출력할 정점 버퍼를 디바이스의 데이터 스트림과 연결시킨다.
        g_pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOMVERTEX));

        //현재의 정점 스트림 선언을 설정한다.
        //정점 포멧을 디바이스에 설정
        g_pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);


        //기본 도형을그리는데 사용
        //렌더링 하는 기본도형의 종류
        //로드하는 최초의 정점의 인덱스
        //렌더링 하는 기본도형의 수
        //폴리곤을 그린다.
        g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 5);


        // End the scene
        g_pd3dDevice->EndScene();
    }

    // Present the backbuffer contents to the display
    g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_DESTROY:
        Cleanup();
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}




//-----------------------------------------------------------------------------
// Name: wWinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
INT WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, INT)
{
    UNREFERENCED_PARAMETER(hInst);

    // Register the window class
    WNDCLASSEX wc =
    {
        sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
        GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
        L"D3D Tutorial", NULL
    };
    RegisterClassEx(&wc);

    // Create the application's window
    HWND hWnd = CreateWindow(L"D3D Tutorial", L"D3D Tutorial 02: Vertices", WS_OVERLAPPEDWINDOW, 100, 100, 1000, 700, NULL, NULL, wc.hInstance, NULL);

    // Initialize Direct3D
    if (SUCCEEDED(InitD3D(hWnd)))
    {
        // Create the vertex buffer
        if (SUCCEEDED(InitVB()))
        {
            // Show the window
            ShowWindow(hWnd, SW_SHOWDEFAULT);
            UpdateWindow(hWnd);

            // Enter the message loop
            MSG msg;
            ZeroMemory(&msg, sizeof(msg));
            while (msg.message != WM_QUIT)
            {
                if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
                {
                    TranslateMessage(&msg);
                    DispatchMessage(&msg);
                }
                else
                    Render();
            }
        }
    }

    UnregisterClass(L"D3D Tutorial", wc.hInstance);
    return 0;
}

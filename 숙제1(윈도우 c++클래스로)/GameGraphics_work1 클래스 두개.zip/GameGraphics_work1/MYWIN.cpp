#include "MYWIN.h"
#include "Resource.h"

C_MYWIN* C_MYWIN::m_pMyWin = nullptr;
WinProc* C_MYWIN::C_WinProc = nullptr;



C_MYWIN::C_MYWIN() :m_hInstance(NULL),m_hWnd(NULL)
{

}

//�����Լ��� ������ ���� winprocŬ������ ���⼭ �������ش�.
void C_MYWIN::createWin()
{
    if (!m_pMyWin)
        m_pMyWin = new C_MYWIN();

    if (C_WinProc == nullptr)
    {
        C_WinProc = new WinProc();
        C_WinProc->Init(C_WinProc);
    }
        

}

C_MYWIN* C_MYWIN::getWin()
{
    return m_pMyWin;
}

void C_MYWIN::releaseWin()
{
    if (m_pMyWin)
    {
        delete m_pMyWin;
        m_pMyWin = nullptr;
    }

    if (C_WinProc)
    {
        delete C_WinProc;
        C_WinProc = nullptr;
    }
}

ATOM C_MYWIN::MyRegisterClass(HINSTANCE hInstance)
{
    //������ Ŭ���� ���
    WNDCLASSEXW wcex;
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = /*wndProc;*/ C_WinProc->wndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_GAMEGRAPHICSWORK1));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = 0;
    wcex.lpszClassName = TEXT("winclass");
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
    return RegisterClassExW(&wcex);
}


bool C_MYWIN::init(HINSTANCE hInstance,int nCmdShow)
{
    m_hInstance = hInstance;

    //������ ����
    m_hWnd = CreateWindowW(TEXT("winclass"), TEXT("������"), WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

    if (!m_hWnd)
        return false;

    
    ShowWindow(m_hWnd, nCmdShow);
    UpdateWindow(m_hWnd);

    return true;
}

void C_MYWIN::updateMsg()
{
    MSG msg = {};

    while (1)
    {
        if (PeekMessage(&msg, nullptr/**/, 0, 0, PM_REMOVE))
        {
            if (msg.message == WM_QUIT)
            {
                break;
            }
            TranslateMessage(&msg);
            DispatchMessage(&msg);

        }
    }
    
}


LRESULT C_MYWIN::wndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    return m_pMyWin->myProc(hWnd, message, wParam, lParam);
}

LRESULT C_MYWIN::myProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: ���⿡ hdc�� ����ϴ� �׸��� �ڵ带 �߰��մϴ�.
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}
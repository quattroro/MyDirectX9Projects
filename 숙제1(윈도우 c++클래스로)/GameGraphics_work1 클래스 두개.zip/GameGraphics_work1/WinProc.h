#pragma once
#include <Windows.h>

class WinProc
{
private:
	static WinProc* m_pMyWin;

public:
	void Init(WinProc* m_myproc);
	static LRESULT CALLBACK wndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);//
	LRESULT CALLBACK myProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

};


#pragma once
#include <d3dx9.h>

struct CUSTOMVERTEX
{
	D3DXVECTOR3 position; // The position
	D3DCOLOR color;    // The color
};
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_DIFFUSE)

class IndexBox
{
public:
	~IndexBox()
	{
		m_pVB->Release();
		m_pIB->Release();
	}

	IndexBox(LPDIRECT3DDEVICE9 device, CUSTOMVERTEX* Vertices, int vnum, WORD* Indices, int inum)
	{
		this->m_pd3dDevice = device;
		this->VNum = vnum;
		this->INum = inum;

		m_pd3dDevice->CreateVertexBuffer(vnum * sizeof(CUSTOMVERTEX), 0, D3DFVF_CUSTOMVERTEX, D3DPOOL_DEFAULT, &m_pVB, NULL);
		CUSTOMVERTEX* pVertices;
		m_pVB->Lock(0, vnum * sizeof(CUSTOMVERTEX), (void**)&pVertices, 0);
		memcpy(pVertices, Vertices, vnum * sizeof(CUSTOMVERTEX));
		m_pVB->Unlock();


		m_pd3dDevice->CreateIndexBuffer(inum * sizeof(WORD), 0, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &m_pIB, NULL);

		VOID* pIndices;
		m_pIB->Lock(0, inum*sizeof(WORD), (void**)&pIndices, 0);
		memcpy(pIndices, Indices, inum * sizeof(WORD));
		m_pIB->Unlock();


	}

	void Render()
	{
		m_pd3dDevice->SetStreamSource(0, m_pVB, 0, sizeof(CUSTOMVERTEX));
		m_pd3dDevice->SetIndices(m_pIB);
		m_pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);
		m_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, VNum, 0, 12);
	}

private:
	LPDIRECT3DDEVICE9       m_pd3dDevice;
	LPDIRECT3DVERTEXBUFFER9 m_pVB;
	LPDIRECT3DINDEXBUFFER9 m_pIB;

	int VNum;
	int INum;
};


#include "d3dUtility.h"
#include "IndexBox.h"

LPDIRECT3DDEVICE9   g_pd3dDevice = NULL; // Our rendering device


bool Render(float time);
void Release();
//LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
IndexBox* box;


void Init()
{
    // Turn off culling
    g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

    // Turn off D3D lighting
    g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);

    CUSTOMVERTEX g_Vertices[] = {
        { D3DXVECTOR3( -1.0f, 1.0f,  1.0f) ,  D3DCOLOR_RGBA(255, 0, 255, 255) },
        { D3DXVECTOR3(1.0f, 1.0f,  1.0f)  , D3DCOLOR_RGBA(255, 255, 0, 0) },
        { D3DXVECTOR3(1.0f, 1.0f, -1.0f)  , D3DCOLOR_RGBA(255, 0, 255, 0) },
        { D3DXVECTOR3(-1.0f, 1.0f, -1.0f)  , D3DCOLOR_RGBA(255, 255, 0, 255) },

        { D3DXVECTOR3(-1.0f, -1.0f,  1.0f) , D3DCOLOR_RGBA(255, 0, 255, 255) },
        { D3DXVECTOR3(1.0f, -1.0f,  1.0f) , D3DCOLOR_RGBA(255, 255, 0, 0) },
        { D3DXVECTOR3(1.0f, -1.0f, -1.0f) , D3DCOLOR_RGBA(255, 0, 255, 0) },
        { D3DXVECTOR3(-1.0f, -1.0f, -1.0f) , D3DCOLOR_RGBA(255, 255, 0, 255) }
    };

    WORD Indices[] =
    {
            0, 1, 2,
            0, 2, 3,
            4, 6, 5,
            4, 7, 6,
            0, 3, 7,
            0, 7, 4,
            1, 5, 6,
            1, 6, 2,
            3, 2, 6,
            3, 6, 7,
            0, 4, 5,
            0, 5, 1
    };

    box = new IndexBox(g_pd3dDevice, g_Vertices, 8, Indices, 36);
}

VOID SetupMatrices()
{
    D3DXMATRIXA16 matWorld;
    D3DXMatrixIdentity(&matWorld);
    D3DXMatrixRotationX(&matWorld, timeGetTime() / 1000.0f);
    g_pd3dDevice->SetTransform(D3DTS_WORLD, &matWorld);

    D3DXVECTOR3 vEyePt(0.0f, 0.0f, -20.0f);
    D3DXVECTOR3 vLookatPt(0.0f, 0.0f, 0.0f);
    D3DXVECTOR3 vUpVec(0.0f, 1.0f, 0.0f);
    D3DXMATRIXA16 matView;
    D3DXMatrixLookAtLH(&matView, &vEyePt, &vLookatPt, &vUpVec);
    g_pd3dDevice->SetTransform(D3DTS_VIEW, &matView);

    D3DXMATRIXA16 matProj;
    D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI / 4, 1.0f, 1.0f, 100.0f);
    g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj);
}

INT WINAPI wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPWSTR lpCmdLine, _In_ int  nCmdShow)
{
	d3d::InitD3D(hInstance, 1500, 1000, true, D3DDEVTYPE_HAL, &g_pd3dDevice);

    Init();

	d3d::EnterMsgLoop(Render);

    Release();
}

bool Render(float time)
{
    //d3d::DeltaTime = time;
    //KeyInput();

    if (g_pd3dDevice != NULL)
    {
        // Clear the backbuffer and the zbuffer
        g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0);
        
        // Begin the scene
        if (SUCCEEDED(g_pd3dDevice->BeginScene()))
        {
            SetupMatrices();
            box->Render();
            

            // End the scene
            g_pd3dDevice->EndScene();
        }

        // Present the backbuffer contents to the display
        g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
    }

    return true;
}

void Release()
{
    delete box;
    d3d::Release<LPDIRECT3DDEVICE9>(g_pd3dDevice);
    
}


LRESULT WINAPI d3d::WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}
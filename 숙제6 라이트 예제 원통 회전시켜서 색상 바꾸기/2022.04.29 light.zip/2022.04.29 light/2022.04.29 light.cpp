﻿//-----------------------------------------------------------------------------
// File: Lights.cpp
//
// Desc: Rendering 3D geometry is much more interesting when dynamic lighting
//       is added to the scene. To use lighting in D3D, you must create one or
//       lights, setup a material, and make sure your geometry contains surface
//       normals. Lights may have a position, a color, and be of a certain type
//       such as directional (light comes from one direction), point (light
//       comes from a specific x,y,z coordinate and radiates in all directions)
//       or spotlight. Materials describe the surface of your geometry,
//       specifically, how it gets lit (diffuse color, ambient color, etc.).
//       Surface normals are part of a vertex, and are needed for the D3D's
//       internal lighting calculations.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#pragma comment(lib,"d3dx9.lib")
#pragma comment(lib,"d3d9.lib")
#pragma comment(lib,"winmm.lib")
#include <Windows.h>
#include <mmsystem.h>
#include <d3dx9.h>
#pragma warning( disable : 4996 ) // disable deprecated warning 
#include <strsafe.h>
#pragma warning( default : 4996 )




//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
LPDIRECT3D9             g_pD3D = NULL; // Used to create the D3DDevice
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL; // Our rendering device
LPDIRECT3DVERTEXBUFFER9 g_pVB = NULL; // Buffer to hold vertices

// A structure for our custom vertex type. We added a normal, and omitted the
// color (which is provided by the material)
struct CUSTOMVERTEX
{
    D3DXVECTOR3 position;
    D3DXVECTOR3 normal;
};

// Our custom FVF, which describes our custom vertex structure
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL)

bool AutoRotate;



D3DXVECTOR2 MoveMousePos;
D3DXVECTOR2 StartMousePos;
bool OnClicked;

//D3DXVECTOR2 curRotate;
//D3DXVECTOR2 RotVal;

int pretemp;

float r = 1.0f;
float g = 1.0f;
float b = 0.0f;


D3DXVECTOR2 ChangeRotVal;
D3DXVECTOR2 CurRotVal;
D3DXVECTOR2 StartRotVal;

UINT LastTime;
DWORD curtime;
float AutoSpeed = 10.0f;
int tikcount;


//-----------------------------------------------------------------------------
// Name: InitD3D()
// Desc: Initializes Direct3D
//-----------------------------------------------------------------------------
HRESULT InitD3D(HWND hWnd)
{
    // Create the D3D object.
    if (NULL == (g_pD3D = Direct3DCreate9(D3D_SDK_VERSION)))
        return E_FAIL;

    // Set up the structure used to create the D3DDevice. Since we are now
    // using more complex geometry, we will create a device with a zbuffer.
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory(&d3dpp, sizeof(d3dpp));
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

    // Create the D3DDevice
    if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
        D3DCREATE_SOFTWARE_VERTEXPROCESSING,
        &d3dpp, &g_pd3dDevice)))
    {
        return E_FAIL;
    }

    // Turn off culling
    g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

    // Turn on the zbuffer
    g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitGeometry()
// Desc: Creates the scene geometry
//-----------------------------------------------------------------------------
HRESULT InitGeometry()
{
    // Create the vertex buffer.
    if (FAILED(g_pd3dDevice->CreateVertexBuffer(50 * 2 * sizeof(CUSTOMVERTEX),
        0, D3DFVF_CUSTOMVERTEX,
        D3DPOOL_DEFAULT, &g_pVB, NULL)))
    {
        return E_FAIL;
    }

    // Fill the vertex buffer. We are algorithmically generating a cylinder
    // here, including the normals, which are used for lighting.
    CUSTOMVERTEX* pVertices;
    if (FAILED(g_pVB->Lock(0, 0, (void**)&pVertices, 0)))
        return E_FAIL;
    for (DWORD i = 0; i < 50; i++) //삼각형을 이용해서 원통을 그리는 알고리즘
    {
        FLOAT theta = (2 * D3DX_PI * i) / (50 - 1);
        pVertices[2 * i + 0].position = D3DXVECTOR3(sinf(theta), -1.0f, cosf(theta));
        pVertices[2 * i + 0].normal = D3DXVECTOR3(sinf(theta), 0.0f, cosf(theta));
        pVertices[2 * i + 1].position = D3DXVECTOR3(sinf(theta), 1.0f, cosf(theta));
        pVertices[2 * i + 1].normal = D3DXVECTOR3(sinf(theta), 0.0f, cosf(theta));
    }
    g_pVB->Unlock();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all previously initialized objects
//-----------------------------------------------------------------------------
VOID Cleanup()
{
    if (g_pVB != NULL)
        g_pVB->Release();

    if (g_pd3dDevice != NULL)
        g_pd3dDevice->Release();

    if (g_pD3D != NULL)
        g_pD3D->Release();
}


void Rotate(float x, float y)
{

}

//-----------------------------------------------------------------------------
// Name: SetupMatrices()
// Desc: Sets up the world, view, and projection transform matrices.
//-----------------------------------------------------------------------------
VOID SetupMatrices()
{
    D3DXMATRIXA16 matWorld;
    D3DXMATRIXA16 XRot;
    D3DXMATRIXA16 YRot;
    D3DXMatrixIdentity(&matWorld);
    //curtime = timeGetTime();
    if (!AutoRotate)
    {
        if (OnClicked)
        {
            ChangeRotVal.x = (MoveMousePos.y - StartMousePos.y) * -1.0f;

            ChangeRotVal.y = (MoveMousePos.x - StartMousePos.x) * -1.0f;

            if (ChangeRotVal.x >= 0)
            {
                if ((int)ChangeRotVal.x >= 180)
                {
                    r = rand() % 2;
                    g = rand() % 2;
                    b = rand() % 2;
                    StartMousePos.y = MoveMousePos.y;
                    StartRotVal.x += 180.0f;
                    ChangeRotVal.x -= 180.0f;
                }
            }
            else
            {
                if ((int)ChangeRotVal.x <= -180)
                {
                    r = rand() % 2;
                    g = rand() % 2;
                    b = rand() % 2;
                    StartMousePos.y = MoveMousePos.y;
                    StartRotVal.x -= 180.0f;
                    ChangeRotVal.x += 180.0f;
                }
            }
			
            if (ChangeRotVal.y >= 0)
            {
                if ((int)ChangeRotVal.y >= 180)
                {
                    r = rand() % 2;
                    g = rand() % 2;
                    b = rand() % 2;
                    StartMousePos.x = MoveMousePos.x;
                    StartRotVal.y += 180.0f;
                    ChangeRotVal.y -= 180.0f;
                    //ChangeRotVal.y = 0;
                }
            }
            else
            {
                if ((int)ChangeRotVal.y <= -180)
                {
                    r = rand() % 2;
                    g = rand() % 2;
                    b = rand() % 2;
                    StartMousePos.x = MoveMousePos.x;
                    StartRotVal.y -= 180.0f;
                    ChangeRotVal.y += 180.0f;
                    //ChangeRotVal.y = 0;
                }
            }

           
        }
    }
    else
    {
        UINT time = timeGetTime() - LastTime;
        if (time>=100)
        {
            LastTime = timeGetTime();
            CurRotVal.x += AutoSpeed;
            tikcount++;
            if (tikcount>=180/AutoSpeed)
            {
                r = rand() % 2;
                g = rand() % 2;
                b = rand() % 2;
                tikcount = 0;
            }
        }
        

    }

    if(!AutoRotate)
        CurRotVal = StartRotVal + ChangeRotVal;

    D3DXMatrixRotationX(&XRot, CurRotVal.x * 3.14f / 180.0f);

    D3DXMatrixRotationY(&YRot, CurRotVal.y * 3.14f / 180.0f);

    D3DXMatrixMultiply(&matWorld, &matWorld, &XRot);

    D3DXMatrixMultiply(&matWorld, &matWorld, &YRot);

    g_pd3dDevice->SetTransform(D3DTS_WORLD, &matWorld);

    // Set up world matrix
    
    

    // Set up our view matrix. A view matrix can be defined given an eye point,
    // a point to lookat, and a direction for which way is up. Here, we set the
    // eye five units back along the z-axis and up three units, look at the
    // origin, and define "up" to be in the y-direction.
    D3DXVECTOR3 vEyePt(0.0f, 3.0f, -5.0f);
    D3DXVECTOR3 vLookatPt(0.0f, 0.0f, 0.0f);
    D3DXVECTOR3 vUpVec(0.0f, 1.0f, 0.0f);
    D3DXMATRIXA16 matView;
    D3DXMatrixLookAtLH(&matView, &vEyePt, &vLookatPt, &vUpVec);
    g_pd3dDevice->SetTransform(D3DTS_VIEW, &matView);

    // For the projection matrix, we set up a perspective transform (which
    // transforms geometry from 3D view space to 2D viewport space, with
    // a perspective divide making objects smaller in the distance). To build
    // a perpsective transform, we need the field of view (1/4 pi is common),
    // the aspect ratio, and the near and far clipping planes (which define at
    // what distances geometry should be no longer be rendered).
    D3DXMATRIXA16 matProj;
    D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI / 4, 1.0f, 1.0f, 100.0f);
    g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj);
}




//-----------------------------------------------------------------------------
// Name: SetupLights()
// Desc: Sets up the lights and materials for the scene.
//-----------------------------------------------------------------------------
VOID SetupLights()
{
    // Set up a material. The material here just has the diffuse and ambient
    // colors set to yellow. Note that only one material can be used at a time.
    D3DMATERIAL9 mtrl;
    ZeroMemory(&mtrl, sizeof(D3DMATERIAL9));
   
    mtrl.Diffuse.r = mtrl.Ambient.r = r;
    mtrl.Diffuse.g = mtrl.Ambient.g = g;
    mtrl.Diffuse.b = mtrl.Ambient.b = b;
    mtrl.Diffuse.a = mtrl.Ambient.a = 1.0f;

    

    g_pd3dDevice->SetMaterial(&mtrl);

    // Set up a white, directional light, with an oscillating direction.
    // Note that many lights may be active at a time (but each one slows down
    // the rendering of our scene). However, here we are just using one. Also,
    // we need to set the D3DRS_LIGHTING renderstate to enable lighting
    D3DXVECTOR3 vecDir;
    D3DLIGHT9 light;
   // ZeroMemory(&light, sizeof(D3DLIGHT9));
   // light.Type = D3DLIGHT_POINT;

   // light.Diffuse.r = 1.0f;
   // light.Diffuse.g = 1.0f;
   // light.Diffuse.b = 1.0f;

   // //vecDir = D3DXVECTOR3(cosf(timeGetTime() / 350.0f), 1.0f, sinf(timeGetTime() / 350.0f));
   ///* vecDir = D3DXVECTOR3(-1.0f, 0.0f, 0.0f);
   // D3DXVec3Normalize((D3DXVECTOR3*)&light.Direction, &vecDir);*/

   // light.Attenuation0 = 0.000000001f;
   // light.Range = 4.0f;

   // //light.Range = 1000.0f;
   // light.Position.x = 0.0f;
   // light.Position.y = 0.0f;
   // light.Position.z = 5.0f;
   // g_pd3dDevice->SetLight(1, &light);

    /// <summary>
    /// /////////////////////////////////////////////////////////////////
    /// </summary>

    ZeroMemory(&light, sizeof(D3DLIGHT9));
    light.Type = D3DLIGHT_SPOT;

    light.Diffuse.r = 1.0f;
    light.Diffuse.g = 1.0f;
    light.Diffuse.b = 1.0f;
    light.Attenuation0 = 0.000000001f;
    light.Attenuation1 = 0.000000001f;
    light.Attenuation2 = 0.000000001f;
    light.Range = 1000000.0f;

    light.Position.x = 10.0f;
    light.Position.y = 1.0f;
    light.Position.z = 0.0f;

    light.Theta = D3DX_PI / 40.0;//내부각
    light.Phi = D3DX_PI / 10.0;//외부각

    vecDir = D3DXVECTOR3(-1.0f, 0.0f, 0.0f);
    D3DXVec3Normalize((D3DXVECTOR3*)&light.Direction, &vecDir);

    g_pd3dDevice->SetLight(0, &light);


    g_pd3dDevice->LightEnable(1, FALSE);
    g_pd3dDevice->LightEnable(0, TRUE);
    g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, TRUE);

    // Finally, turn on some ambient light.
    g_pd3dDevice->SetRenderState(D3DRS_AMBIENT, 0x0002020);
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID Render()
{
    // Clear the backbuffer and the zbuffer
    g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
        D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0);

    // Begin the scene
    if (SUCCEEDED(g_pd3dDevice->BeginScene()))
    {
        // Setup the lights and materials
        SetupLights();

        // Setup the world, view, and projection matrices
        SetupMatrices();

        // Render the vertex buffer contents
        g_pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOMVERTEX));
        g_pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);
        g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2 * 50 - 2);

        // End the scene
        g_pd3dDevice->EndScene();
    }

    // Present the backbuffer contents to the display
    g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;
    switch (msg)
    {
    case WM_KEYDOWN:
        if (wParam == '1')
        {
            if (AutoRotate)
            {
                AutoRotate = false;
            }
        }

        if (wParam == '2')
        {
            if (!AutoRotate)
            {
                AutoRotate = true;
                LastTime = timeGetTime();
            }
        }
        break;

    case WM_LBUTTONDOWN:
        OnClicked = true;
        StartMousePos = D3DXVECTOR2(LOWORD(lParam), HIWORD(lParam));
        MoveMousePos = StartMousePos;
        break;

    case WM_LBUTTONUP:
        OnClicked = false;
        StartRotVal = CurRotVal;
        ChangeRotVal = D3DXVECTOR2(0.0f, 0.0f);
        CurRotVal = D3DXVECTOR2(0.0f, 0.0f);
        StartMousePos = D3DXVECTOR2(0.0f,0.0f);
        MoveMousePos = D3DXVECTOR2(0.0f, 0.0f);
        break;

        //마우스 10만큼의 이동을 1도로 정한다.
    case WM_MOUSEMOVE:
        if (OnClicked)
        {
            MoveMousePos = D3DXVECTOR2(LOWORD(lParam), HIWORD(lParam));
            
            InvalidateRect(hWnd, NULL, TRUE);
        }
        break;

    case WM_PAINT:
    {
        HDC hdc = BeginPaint(hWnd, &ps);
        TCHAR str[255] = { 0 };
        
        swprintf(str, TEXT("startx -> %3.3f, x -> %3.3f ,ChangeX -> %3.3f"),StartRotVal.x, CurRotVal.x,ChangeRotVal.x);
        TextOut(hdc, 100, 100, str, lstrlen(str));
        swprintf(str, TEXT("starty -> %3.3f, y -> %3.3f,Changey -> %3.3f"),StartRotVal.y , CurRotVal.y, ChangeRotVal.y);
        TextOut(hdc, 100, 120, str, lstrlen(str));

        swprintf(str, TEXT("tiem -> %d"), curtime);
        TextOut(hdc, 100, 140, str, lstrlen(str));

        EndPaint(hWnd, &ps);
    }
        break;


    case WM_DESTROY:
        Cleanup();
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}




//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
INT WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, INT)
{
    UNREFERENCED_PARAMETER(hInst);

    // Register the window class
    WNDCLASSEX wc =
    {
        sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
        GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
        L"D3D Tutorial", NULL
    };
    RegisterClassEx(&wc);

    // Create the application's window
    HWND hWnd = CreateWindow(L"D3D Tutorial", L"D3D Tutorial 04: Lights",
        WS_OVERLAPPEDWINDOW, 100, 100, 800, 800,
        NULL, NULL, wc.hInstance, NULL);

    // Initialize Direct3D
    if (SUCCEEDED(InitD3D(hWnd)))
    {
        // Create the geometry
        if (SUCCEEDED(InitGeometry()))
        {
            // Show the window
            ShowWindow(hWnd, SW_SHOWDEFAULT);
            UpdateWindow(hWnd);

            // Enter the message loop
            MSG msg;
            ZeroMemory(&msg, sizeof(msg));
            while (msg.message != WM_QUIT)
            {
                if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
                {
                    TranslateMessage(&msg);
                    DispatchMessage(&msg);
                }
                else
                    Render();
            }
        }
    }

    UnregisterClass(L"D3D Tutorial", wc.hInstance);
    return 0;
}



﻿#pragma comment(lib,"d3dx9.lib")
#pragma comment(lib,"d3d9.lib")
#pragma comment(lib,"winmm.lib")
#include <Windows.h>
#include <mmsystem.h>
#include <d3dx9.h>

#pragma warning( disable : 4996 ) // disable deprecated warning 
#include <strsafe.h>
#pragma warning( default : 4996 )
#include "Planet.h"
#include "SpaceShip.h"
#include "Camera.h"


//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
LPDIRECT3D9             g_pD3D = NULL; // Used to create the D3DDevice
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL; // Our rendering device
LPDIRECT3DVERTEXBUFFER9 g_pVB = NULL; // Buffer to hold vertices
LPD3DXMESH m_pSphereMesh;



// A structure for our custom vertex type. We added a normal, and omitted the
// color (which is provided by the material)
struct CUSTOMVERTEX
{
    D3DXVECTOR3 position;
    D3DXVECTOR3 normal;
};

// Our custom FVF, which describes our custom vertex structure
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL)




bool AutoRotate;

Planet* planet;
Planet* planet2;

Planet* planets[20];
SpaceShip* ship;
Camera* camera;

D3DXVECTOR2 MoveMousePos;
D3DXVECTOR2 StartMousePos;
bool OnClicked;

//D3DXVECTOR2 curRotate;
//D3DXVECTOR2 RotVal;

int pretemp;

float r = 1.0f;
float g = 0.0f;
float b = 0.0f;


D3DXVECTOR2 ChangeRotVal;
D3DXVECTOR2 CurRotVal;
D3DXVECTOR2 StartRotVal;

UINT LastTime;
DWORD curtime;
float AutoSpeed = 10.0f;
int tikcount;

bool keybuf[256];

int moveselect = 0;

//-----------------------------------------------------------------------------
// Name: InitD3D()
// Desc: Initializes Direct3D
//-----------------------------------------------------------------------------
HRESULT InitD3D(HWND hWnd)
{
    // Create the D3D object.
    if (NULL == (g_pD3D = Direct3DCreate9(D3D_SDK_VERSION)))
        return E_FAIL;

    // Set up the structure used to create the D3DDevice. Since we are now
    // using more complex geometry, we will create a device with a zbuffer.
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory(&d3dpp, sizeof(d3dpp));
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

    // Create the D3DDevice
    if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
        D3DCREATE_SOFTWARE_VERTEXPROCESSING,
        &d3dpp, &g_pd3dDevice)))
    {
        return E_FAIL;
    }

    // Turn off culling
    g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

    // Turn on the zbuffer
    g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);

    planets[0] = new Planet(g_pd3dDevice, D3DXVECTOR3(0, 0, 0), 1.8, D3DXVECTOR3(0, 0, 0), 1, true);
    planets[1] = new Planet(g_pd3dDevice, D3DXVECTOR3(4, 0, 0), 0.4, D3DXVECTOR3(0, 0, 0), 1, false);
    planets[2] = new Planet(g_pd3dDevice, D3DXVECTOR3(0, 0, 0), 0.2, D3DXVECTOR3(0, 0, 0), 2, false);
    planets[1]->SetSatellite(planets[2], D3DXVECTOR3(0.7, 0, 0));

    planets[3] = new Planet(g_pd3dDevice, D3DXVECTOR3(5, 0, 0), 0.6, D3DXVECTOR3(0, 0, 0), 0.2, false);
    planets[4] = new Planet(g_pd3dDevice, D3DXVECTOR3(8.2, 0, 0), 1, D3DXVECTOR3(0, 0, 0), 2, false);
    planets[5] = new Planet(g_pd3dDevice, D3DXVECTOR3(9, 0, 0), 1.4, D3DXVECTOR3(0, 0, 0), 1.5, false);
    planets[6] = new Planet(g_pd3dDevice, D3DXVECTOR3(-10, 0, 0), 1.3, D3DXVECTOR3(0, 0, 0), 1.6, false);
    planets[7] = new Planet(g_pd3dDevice, D3DXVECTOR3(-13, 0, 0), 0.8, D3DXVECTOR3(0, 0, 0), 1.8, false);
    planets[8] = new Planet(g_pd3dDevice, D3DXVECTOR3(15, 0, 0), 1.1, D3DXVECTOR3(0, 0, 0), 0.3, false);
    planets[9] = new Planet(g_pd3dDevice, D3DXVECTOR3(-17, 0, 0), 1, D3DXVECTOR3(0, 0, 0), 0.5, false);

    ship = new SpaceShip(g_pd3dDevice, D3DXVECTOR3(5, 0, 0), 0.1, 0.1,0.5, 0.2);

    camera = new Camera(g_pd3dDevice, D3DXVECTOR3(20.0f, 20.0f, 0.0f), D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f));

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitGeometry()
// Desc: Creates the scene geometry
//-----------------------------------------------------------------------------
HRESULT InitGeometry()
{
    // Create the vertex buffer.
    if (FAILED(g_pd3dDevice->CreateVertexBuffer(50 * 2 * sizeof(CUSTOMVERTEX),
        0, D3DFVF_CUSTOMVERTEX,
        D3DPOOL_DEFAULT, &g_pVB, NULL)))
    {
        return E_FAIL;
    }

    // Fill the vertex buffer. We are algorithmically generating a cylinder
    // here, including the normals, which are used for lighting.
    CUSTOMVERTEX* pVertices;
    if (FAILED(g_pVB->Lock(0, 0, (void**)&pVertices, 0)))
        return E_FAIL;
    for (DWORD i = 0; i < 50; i++) //삼각형을 이용해서 원통을 그리는 알고리즘
    {
        FLOAT theta = (2 * D3DX_PI * i) / (50 - 1);
        pVertices[2 * i + 0].position = D3DXVECTOR3(sinf(theta), -1.0f, cosf(theta));
        pVertices[2 * i + 0].normal = D3DXVECTOR3(sinf(theta), 0.0f, cosf(theta));
        pVertices[2 * i + 1].position = D3DXVECTOR3(sinf(theta), 1.0f, cosf(theta));
        pVertices[2 * i + 1].normal = D3DXVECTOR3(sinf(theta), 0.0f, cosf(theta));
    }
    g_pVB->Unlock();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all previously initialized objects
//-----------------------------------------------------------------------------
VOID Cleanup()
{
    if (g_pVB != NULL)
        g_pVB->Release();

    if (g_pd3dDevice != NULL)
        g_pd3dDevice->Release();

    if (g_pD3D != NULL)
        g_pD3D->Release();
}


void Rotate(float x, float y)
{

}

//-----------------------------------------------------------------------------
// Name: SetupMatrices()
// Desc: Sets up the world, view, and projection transform matrices.
//-----------------------------------------------------------------------------
VOID SetupMatrices()
{
    //D3DXMATRIXA16 matWorld;
    D3DXMATRIXA16 XRot;
    D3DXMATRIXA16 YRot;


    if (!AutoRotate)
        CurRotVal = StartRotVal + ChangeRotVal;


}




//-----------------------------------------------------------------------------
// Name: SetupLights()
// Desc: Sets up the lights and materials for the scene.
//-----------------------------------------------------------------------------
VOID SetupLights()
{
    // Set up a material. The material here just has the diffuse and ambient
    // colors set to yellow. Note that only one material can be used at a time.
    D3DMATERIAL9 mtrl;
    ZeroMemory(&mtrl, sizeof(D3DMATERIAL9));

    mtrl.Diffuse.r = mtrl.Ambient.r = r;
    mtrl.Diffuse.g = mtrl.Ambient.g = g;
    mtrl.Diffuse.b = mtrl.Ambient.b = b;
    mtrl.Diffuse.a = mtrl.Ambient.a = 1.0f;



    g_pd3dDevice->SetMaterial(&mtrl);

    // Set up a white, directional light, with an oscillating direction.
    // Note that many lights may be active at a time (but each one slows down
    // the rendering of our scene). However, here we are just using one. Also,
    // we need to set the D3DRS_LIGHTING renderstate to enable lighting
    D3DXVECTOR3 vecDir;
    D3DLIGHT9 light;
     ZeroMemory(&light, sizeof(D3DLIGHT9));
     light.Type = D3DLIGHT_POINT;

     light.Diffuse.r = 1.0f;
     light.Diffuse.g = 1.0f;
     light.Diffuse.b = 1.0f;

     //vecDir = D3DXVECTOR3(cosf(timeGetTime() / 350.0f), 1.0f, sinf(timeGetTime() / 350.0f));
    /* vecDir = D3DXVECTOR3(-1.0f, 0.0f, 0.0f);
     D3DXVec3Normalize((D3DXVECTOR3*)&light.Direction, &vecDir);*/

     light.Attenuation0 = 0.000000001f;
     light.Range = 500.0f;

     //light.Range = 1000.0f;
     light.Position.x = 0.0f;
     light.Position.y = 0.0f;
     light.Position.z = 0.0f;
     g_pd3dDevice->SetLight(1, &light);

     


    g_pd3dDevice->LightEnable(0, FALSE);
    g_pd3dDevice->LightEnable(1, TRUE);
    g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, TRUE);

    // Finally, turn on some ambient light.
    g_pd3dDevice->SetRenderState(D3DRS_AMBIENT, 0x0002020);
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID Render()
{
    // Clear the backbuffer and the zbuffer
    g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
        D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0);

    // Begin the scene
    if (SUCCEEDED(g_pd3dDevice->BeginScene()))
    {
        // Setup the lights and materials
        SetupLights();

        // Setup the world, view, and projection matrices
        SetupMatrices();

        // Render the vertex buffer contents
        g_pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOMVERTEX));
        g_pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);
        //g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2 * 50 - 2);

        for (int i = 0; i < 9; i++)
        {
            planets[i]->Render();
        }
        ship->Render();
        camera->Render();
        /*planet->Render();
        planet2->Render();*/
        // End the scene
        g_pd3dDevice->EndScene();
    }

    // Present the backbuffer contents to the display
    g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}

void KeyInput()
{
    if (keybuf['W'])
    {
        
        if (OnClicked)
        {
            camera->FowardMove();
        }
        else
        {
            ship->FowardMove();
        }
    }

    if (keybuf['S'])
    {
        
        if (OnClicked)
        {
            camera->BackMove();
        }
        else
        {
            ship->BackMove();
        }
    }

    if (keybuf['A'])
    {
        
        //ship->LeftRot();
        //ship->LeftMove();
        if (OnClicked)
        {
            camera->LeftMove();
        }
        else
        {
            ship->RightRot();
        }
    }

    if (keybuf['D'])
    {
        
        //ship->RightRot();
        //ship->RightMove();
        if (OnClicked)
        {
            camera->RightMove();
        }
        else
        {
            ship->LeftRot();
        }
    }
}



//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;
    switch (msg)
    {
    case WM_KEYDOWN:
        if (wParam == '1')
        {
            camera->SetMoveMode(0);
            /*if (AutoRotate)
            {
                AutoRotate = false;
            }*/
        }

        if (wParam == '2')
        {
            camera->SetMoveMode(1);
            /*if (!AutoRotate)
            {
                AutoRotate = true;
                LastTime = timeGetTime();
            }*/
        }

        if (wParam == '3')
        {
            camera->SetMoveMode(2);
            ship->SetCamera((GameObject*)camera, D3DXVECTOR3(0, 2, -10));
            /*if (!AutoRotate)
            {
                AutoRotate = true;
                LastTime = timeGetTime();
            }*/
        }

        keybuf[wParam] = true;

        break;

    case WM_KEYUP:
        keybuf[wParam] = false;
        break;

    case WM_LBUTTONDOWN:
        OnClicked = true;
        StartMousePos = D3DXVECTOR2(LOWORD(lParam), HIWORD(lParam));
        MoveMousePos = StartMousePos;
        break;

    case WM_LBUTTONUP:
        OnClicked = false;
        StartRotVal = CurRotVal;
        ChangeRotVal = D3DXVECTOR2(0.0f, 0.0f);
        CurRotVal = D3DXVECTOR2(0.0f, 0.0f);
        StartMousePos = D3DXVECTOR2(0.0f, 0.0f);
        MoveMousePos = D3DXVECTOR2(0.0f, 0.0f);
        break;

        //마우스 10만큼의 이동을 1도로 정한다.
    case WM_MOUSEMOVE:
        if (OnClicked)
        {
            MoveMousePos = D3DXVECTOR2(LOWORD(lParam), HIWORD(lParam));

            ChangeRotVal.x = (MoveMousePos.y - StartMousePos.y) * -1.0f;

            ChangeRotVal.y = (MoveMousePos.x - StartMousePos.x) * -1.0f;

            StartMousePos = MoveMousePos;

            if (camera->GetMoveMode() != 2)
            {
                camera->RotHor(ChangeRotVal.y);
                camera->RotVir(ChangeRotVal.x);
            }
            else
            {
                ship->VirRot(ChangeRotVal.x);
                ship->HorRot(ChangeRotVal.y);
            }
            
        }
        break;

    case WM_PAINT:
    {
        HDC hdc = BeginPaint(hWnd, &ps);
        TCHAR str[255] = { 0 };

        /*swprintf(str, TEXT("startx -> %3.3f, x -> %3.3f ,ChangeX -> %3.3f"), StartRotVal.x, CurRotVal.x, ChangeRotVal.x);
        TextOut(hdc, 100, 100, str, lstrlen(str));
        swprintf(str, TEXT("starty -> %3.3f, y -> %3.3f,Changey -> %3.3f"), StartRotVal.y, CurRotVal.y, ChangeRotVal.y);
        TextOut(hdc, 100, 120, str, lstrlen(str));

        swprintf(str, TEXT("tiem -> %d"), curtime);
        TextOut(hdc, 100, 140, str, lstrlen(str));*/

        EndPaint(hWnd, &ps);
    }
    break;


    case WM_DESTROY:
        Cleanup();
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}




//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
INT WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, INT)
{
    UNREFERENCED_PARAMETER(hInst);

    // Register the window class
    WNDCLASSEX wc =
    {
        sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
        GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
        L"D3D Tutorial", NULL
    };
    RegisterClassEx(&wc);

    // Create the application's window
    HWND hWnd = CreateWindow(L"D3D Tutorial", L"D3D Tutorial 04: Lights",
        WS_OVERLAPPEDWINDOW, 100, 100, 1300, 1000,
        NULL, NULL, wc.hInstance, NULL);

    // Initialize Direct3D
    if (SUCCEEDED(InitD3D(hWnd)))
    {
        // Create the geometry
        if (SUCCEEDED(InitGeometry()))
        {
            // Show the window
            ShowWindow(hWnd, SW_SHOWDEFAULT);
            UpdateWindow(hWnd);

            // Enter the message loop
            MSG msg;
            ZeroMemory(&msg, sizeof(msg));
            while (msg.message != WM_QUIT)
            {
                if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
                {
                    TranslateMessage(&msg);
                    DispatchMessage(&msg);
                }
                else
                {
                    KeyInput();
                    Render();
                }
                    
            }
        }
    }

    UnregisterClass(L"D3D Tutorial", wc.hInstance);
    return 0;
}



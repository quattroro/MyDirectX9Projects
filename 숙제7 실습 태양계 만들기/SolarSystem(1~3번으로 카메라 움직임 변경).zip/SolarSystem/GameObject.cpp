#include "GameObject.h"

void GameObject::Translation(float x, float y, float z)
{
	D3DXMATRIXA16 transmat;

	//D3DXMatrixTranslation(&transmat, x, y, z);

	//D3DXVec3TransformCoord(&pos, &pos, &transmat);

	this->pos.x += x;
	this->pos.y += y;
	this->pos.z += z;

}

//void GameObject::Rotation(float x, float y, float z)
//{
//	D3DXMATRIXA16 tempmat;
//	
//
//
//}

//�������� 
//��, ��
void GameObject::PitchRotation(float fAngle)
{
	D3DXMATRIXA16 Xrotmat;
	
	rot.x += fAngle;

	D3DXMatrixRotationAxis(&Xrotmat, &Axis[E_Axis_Right], fAngle * 3.14 / 180);

	D3DXVec3TransformNormal(&Axis[E_Axis_Forward], &Axis[E_Axis_Forward], &Xrotmat);
	D3DXVec3TransformNormal(&Axis[E_Axis_Up], &Axis[E_Axis_Up], &Xrotmat);
}

//��������
//��, ����
void GameObject::YawRotation(float fAngle)
{
	D3DXMATRIXA16 Yrotmat;

	rot.y += fAngle;

	D3DXMatrixRotationAxis(&Yrotmat, &Axis[E_Axis_Up], fAngle * 3.14 / 180);

	D3DXVec3TransformNormal(&Axis[E_Axis_Forward], &Axis[E_Axis_Forward], &Yrotmat);
	D3DXVec3TransformNormal(&Axis[E_Axis_Right], &Axis[E_Axis_Right], &Yrotmat);

}

//�����
//��, ����
void GameObject::RollRotation(float fAngle)
{
	D3DXMATRIXA16 Zrotmat;

	rot.z += fAngle;

	D3DXMatrixRotationAxis(&Zrotmat, &Axis[E_Axis_Forward], fAngle * 3.14 / 180);

	D3DXVec3TransformNormal(&Axis[E_Axis_Up], &Axis[E_Axis_Up], &Zrotmat);
	D3DXVec3TransformNormal(&Axis[E_Axis_Right], &Axis[E_Axis_Right], &Zrotmat);
}

void GameObject::Render()
{
	D3DXMATRIXA16 RotMat;
	D3DXMATRIXA16 TransMat;
	D3DXMATRIXA16 ScaleMat;
	D3DXMATRIXA16 TempMat;
	D3DXMATRIXA16 Xrotmat;
	D3DXMATRIXA16 Yrotmat;
	D3DXMATRIXA16 Zrotmat;

	D3DXMatrixIdentity(&TempMat);

	D3DXMatrixTranslation(&TransMat, pos.x, pos.y, pos.z);
	D3DXMatrixMultiply(&TempMat, &TempMat, &TransMat);

	D3DXMatrixRotationAxis(&Xrotmat, &Axis[E_Axis_Right], rot.x);
	D3DXMatrixRotationAxis(&Yrotmat, &Axis[E_Axis_Up], rot.y);
	D3DXMatrixRotationAxis(&Zrotmat, &Axis[E_Axis_Forward], rot.z);
	D3DXMatrixMultiply(&TempMat, &TempMat, &Xrotmat);
	D3DXMatrixMultiply(&TempMat, &TempMat, &Yrotmat);
	D3DXMatrixMultiply(&TempMat, &TempMat, &Zrotmat);

	D3DXMatrixScaling(&ScaleMat, scale.x, scale.y, scale.z);
}


void GameObject::Scale(float x, float y, float z)
{
	this->scale.x = x;
	this->scale.y = y;
	this->scale.z = z;

	D3DXMATRIXA16 scale;

	//D3DXMatrixScaling(&scale, x, y, z);



}



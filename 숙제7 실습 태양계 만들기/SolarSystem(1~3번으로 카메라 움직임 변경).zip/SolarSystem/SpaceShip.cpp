#include "SpaceShip.h"
#include "Camera.h"

void SpaceShip::SetCamera(GameObject* cameraobj, D3DXVECTOR3 pos)
{
	childCamera = cameraobj;
	childCamera->SetParent(this);

	D3DXVECTOR3 temppos = D3DXVECTOR3(this->pos.x +pos.x, this->pos.y + pos.y, this->pos.z+ pos.z);
	D3DXVECTOR3 lookat = D3DXVECTOR3(this->pos.x , this->pos.y + 1.0f, this->pos.z);
	D3DXVECTOR3 up = D3DXVECTOR3(0.0f, 0.1f, 0.0f);
	Camera* camera = (Camera*)childCamera;
	camera->Init(temppos, lookat, up);


}


void SpaceShip::FowardMove()
{
	//this->pos += direction * speed;

	this->pos += this->Axis[E_Axis_Forward] * speed;
	D3DXVECTOR3 temp = this->Axis[E_Axis_Forward] * speed;
	if (childCamera != nullptr)
	{
		childCamera->Translation(temp.x, temp.y, temp.z);
	}

}
void SpaceShip::BackMove()
{
	//this->pos -= direction * speed;
	this->pos -= this->Axis[E_Axis_Forward] * speed;
	D3DXVECTOR3 temp = this->Axis[E_Axis_Forward] * speed * -1;
	if (childCamera != nullptr)
	{
		childCamera->Translation(temp.x, temp.y, temp.z);
	}
}

void SpaceShip::UpRot()
{
	PitchRotation(1 * rotspeed * -1);
	if (childCamera != nullptr)
	{

		childCamera->PitchRotation(1 * rotspeed * -1);

	}

}
void SpaceShip::DownRot()
{
	PitchRotation(1 * rotspeed);
	if (childCamera != nullptr)
	{
		childCamera->PitchRotation(1 * rotspeed);
	}

}



void SpaceShip::RightRot()
{
	/*D3DXVECTOR3 curpos;
	D3DXMATRIXA16 matrot;
	rot.y = rot.y + 1 * rotspeed;
	D3DXMatrixRotationY(&matrot, rot.y * 3.14 / 180);
	D3DXVec3TransformCoord(&direction, &direction, &matrot);*/

	YawRotation(1 * rotspeed*-1);
	if (childCamera != nullptr)
	{
		/*D3DXVECTOR3 temp2 = D3DXVECTOR3(1.0f, 0.0f, 0.0f);
		D3DXVECTOR3 temp = Axis[E_Axis_Forward] + temp2;
		childCamera->LookAt(temp);*/

		childCamera->YawRotation(1 * rotspeed * -1);
		
	}

}
void SpaceShip::LeftRot()
{

	/*D3DXVECTOR3 curpos;
	D3DXMATRIXA16 matrot;
	rot.y = rot.y - 1 * rotspeed;
	D3DXMatrixRotationY(&matrot, rot.y * 3.14 / 180);
	D3DXVec3TransformCoord(&direction, &direction, &matrot);*/
	YawRotation(1 * rotspeed);
	if (childCamera != nullptr)
	{

		/*D3DXVECTOR3 temp2 = D3DXVECTOR3(1.0f, 0.0f, 0.0f);
		D3DXVECTOR3 temp = Axis[E_Axis_Forward] + temp2;
		childCamera->LookAt(temp);*/

		childCamera->YawRotation(1 * rotspeed);
		
	}

}

void SpaceShip::VirRot(float fAngle)
{
	PitchRotation(fAngle*0.1f);
	if (childCamera != nullptr)
	{

		childCamera->PitchRotation(fAngle * 0.1f);

	}
}
void SpaceShip::HorRot(float fAngle)
{
	YawRotation(fAngle * 0.1f);
	if (childCamera != nullptr)
	{

		childCamera->YawRotation(fAngle * 0.1f);

	}
}
#pragma once
#include <Windows.h>
#include <mmsystem.h>
#include <d3dx9.h>
#include <strsafe.h>

#include "GameObject.h"


class Camera :GameObject
{
public:


	Camera(LPDIRECT3DDEVICE9 m_pd3dDevice, D3DXVECTOR3 vEyePt, D3DXVECTOR3 vLookatPt, D3DXVECTOR3 vUpVec)
	{
		this->m_pd3dDevice = m_pd3dDevice;
		this->vEyePt = vEyePt;
		this->vLookatPt = vLookatPt;
		this->vUpVec = vUpVec;

		this->First_vEyePt = vEyePt;
		this->First_vLookatPt = vLookatPt;
		this->First_vUpVec = vUpVec;
	}


	void Init(D3DXVECTOR3 vEyePt, D3DXVECTOR3 vLookatPt, D3DXVECTOR3 vUpVec)
	{
		this->vEyePt = vEyePt;
		this->vLookatPt = vLookatPt;
		this->vUpVec = vUpVec;

		this->First_vEyePt = vEyePt;
		this->First_vLookatPt = vLookatPt;
		this->First_vUpVec = vUpVec;
	}

	//��ġ�� lookat�� ���� �������� �Ѵ�.
	virtual void Translation(float x, float y, float z)
	{
		direction = D3DXVECTOR3(x, y, z);
		vEyePt += direction;
		vLookatPt += direction;
	}

	virtual void Scale(float x, float y, float z)
	{

	}
	//��������
	virtual void PitchRotation(float fAngle)
	{
		D3DXMATRIXA16 tempmat;
		D3DXMATRIXA16 transmat;
		D3DXMATRIXA16 rotmat;
		D3DXMatrixIdentity(&tempmat);

		if (movemode == 0)
		{
			direction = vEyePt - vLookatPt;//ī�޶� �������� �̵���Ų ������ ȸ������ ���Ѵ�.

			D3DXMatrixTranslation(&transmat, direction.x, direction.y, direction.z);

			D3DXMatrixRotationZ(&rotmat, (fAngle * 0.1) * 3.14 / 180);

			D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);
			D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);
			D3DXMatrixTranslation(&transmat, -direction.x, -direction.y, -direction.z);

			D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);


			D3DXVec3TransformCoord(&vLookatPt, &vLookatPt, &tempmat);
		}
		else if (movemode == 1)
		{
			D3DXMatrixRotationY(&rotmat, (fAngle * 0.1) * 3.14 / 180);
			D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);

			D3DXVec3TransformCoord(&vEyePt, &vEyePt, &tempmat);
			D3DXVec3TransformCoord(&vUpVec, &vUpVec, &tempmat);
		}
		else if (movemode == 2)//ī�޶� ��ü�� �پ�������
		{
			//�θ��� ��ġ�� �������� ȸ��
			if (parent != nullptr)
			{
				D3DXVECTOR3 temp = parent->GetPosition() * -1;
				D3DXMatrixTranslation(&transmat, temp.x, temp.y, temp.z);
				D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);

				D3DXMatrixRotationZ(&rotmat, (fAngle) * 3.14 / 180);
				D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);

				temp = temp * -1;
				D3DXMatrixTranslation(&transmat, temp.x, temp.y, temp.z);
				D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);

				D3DXVec3TransformCoord(&vEyePt, &vEyePt, &tempmat);

				D3DXMatrixRotationZ(&rotmat, (fAngle) * 3.14 / 180 * -1);
				//D3DXVec3TransformCoord(&vLookatPt, &vLookatPt, &rotmat);
			}
		}
	}
	//��������
	virtual void YawRotation(float fAngle)
	{
		D3DXMATRIXA16 tempmat;
		D3DXMATRIXA16 transmat;
		D3DXMATRIXA16 rotmat;
		D3DXMatrixIdentity(&tempmat);

		if (movemode == 0)
		{
			//direction = vEyePt - vLookatPt;//ī�޶� �������� �̵���Ų ������ ȸ������ ���Ѵ�.
			direction = vLookatPt - vEyePt;
			D3DXMatrixTranslation(&transmat, direction.x, direction.y, direction.z);
			D3DXMatrixRotationY(&rotmat, (fAngle * 0.1) * 3.14 / 180);

			D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);
			D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);
			D3DXMatrixTranslation(&transmat, -direction.x, -direction.y, -direction.z);
			D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);


			D3DXVec3TransformCoord(&vLookatPt, &vLookatPt, &tempmat);
		}
		else if (movemode == 1)
		{
			direction = vLookatPt - vEyePt;
			D3DXMatrixRotationX(&rotmat, (fAngle * 0.1) * 3.14 / 180);
			D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);

			D3DXVec3TransformCoord(&vEyePt, &vEyePt, &tempmat);

			//D3DXVec3Cross()
		}
		else if (movemode == 2)
		{
			if (parent != nullptr)
			{
				D3DXVECTOR3 temp = parent->GetPosition()*-1;
				D3DXMatrixTranslation(&transmat, temp.x, temp.y, temp.z);
				D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);

				D3DXMatrixRotationY(&rotmat, (fAngle) * 3.14 / 180);
				D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);

				temp = temp * -1;
				D3DXMatrixTranslation(&transmat, temp.x, temp.y, temp.z);
				D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);
				
				D3DXVec3TransformCoord(&vEyePt, &vEyePt, &tempmat);

				D3DXMatrixRotationY(&rotmat, (fAngle) * 3.14 / 180 * -1);
				//D3DXVec3TransformCoord(&vLookatPt, &vLookatPt, &rotmat);


			}
		}
	}
	//�����
	virtual void RollRotation(float fAngle)
	{

	}

	//��������
	void RotHor(float ydegree)
	{

		D3DXMATRIXA16 tempmat;
		D3DXMATRIXA16 transmat;
		D3DXMATRIXA16 rotmat;
		D3DXMatrixIdentity(&tempmat);

		if (movemode == 0)
		{
			direction = vEyePt - vLookatPt;//ī�޶� �������� �̵���Ų ������ ȸ������ ���Ѵ�.

			D3DXMatrixTranslation(&transmat, direction.x, direction.y, direction.z);
			D3DXMatrixRotationY(&rotmat, (ydegree * 0.1) * 3.14 / 180);

			D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);
			D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);
			D3DXMatrixTranslation(&transmat, -direction.x, -direction.y, -direction.z);
			D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);


			D3DXVec3TransformCoord(&vLookatPt, &vLookatPt, &tempmat);
		}
		else if (movemode == 1)
		{
			direction = vLookatPt - vEyePt;
			D3DXMatrixRotationX(&rotmat, (ydegree * 0.1) * 3.14 / 180);
			D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);

			D3DXVec3TransformCoord(&vEyePt, &vEyePt, &tempmat);

			//D3DXVec3Cross()
		}
		else if (movemode == 2)
		{

		}

	}

	//��������
	void RotVir(float xdegree)
	{
		D3DXMATRIXA16 tempmat;
		D3DXMATRIXA16 transmat;
		D3DXMATRIXA16 rotmat;
		D3DXMatrixIdentity(&tempmat);

		if (movemode == 0)
		{
			direction = vEyePt - vLookatPt;//ī�޶� �������� �̵���Ų ������ ȸ������ ���Ѵ�.

			D3DXMatrixTranslation(&transmat, direction.x, direction.y, direction.z);

			D3DXMatrixRotationZ(&rotmat, (xdegree * 0.1) * 3.14 / 180);

			D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);
			D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);
			D3DXMatrixTranslation(&transmat, -direction.x, -direction.y, -direction.z);

			D3DXMatrixMultiply(&tempmat, &tempmat, &transmat);


			D3DXVec3TransformCoord(&vLookatPt, &vLookatPt, &tempmat);
		}
		else if (movemode == 1)
		{
			D3DXMatrixRotationY(&rotmat, (xdegree * 0.1) * 3.14 / 180);
			D3DXMatrixMultiply(&tempmat, &tempmat, &rotmat);

			D3DXVec3TransformCoord(&vEyePt, &vEyePt, &tempmat);
			D3DXVec3TransformCoord(&vUpVec, &vUpVec, &tempmat);
		}
		else if (movemode == 2)//ī�޶� ��ü�� �پ�������
		{
			
		}


	}

	//��ġ�� lookat�� ���� �������� �Ѵ�.
	/*void Translation(float x, float y, float z)
	{
		direction = D3DXVECTOR3(x, y, z);
		vEyePt += direction;
		vLookatPt += direction;
	}*/

	void RightMove()
	{
		direction = vLookatPt - vEyePt;
		D3DXVECTOR3 cross;
		D3DXVECTOR3 upvec = D3DXVECTOR3(0.0f, 0.1f, 0.0f);
		D3DXVec3Cross(&cross, &direction, &upvec);
		D3DXVec3Normalize(&cross, &cross);
		vEyePt += cross * movespeed;
		vLookatPt += cross * movespeed;

	}

	void LeftMove()
	{
		direction = vLookatPt - vEyePt;
		D3DXVECTOR3 cross;
		D3DXVECTOR3 upvec = D3DXVECTOR3(0.0f, 0.1f, 0.0f);
		D3DXVec3Cross(&cross, &direction, &upvec);
		D3DXVec3Normalize(&cross, &cross);
		vEyePt -= cross * movespeed;
		vLookatPt -= cross * movespeed;
	}

	void FowardMove()
	{
		direction = vLookatPt - vEyePt;
		D3DXVec3Normalize(&direction, &direction);
		vEyePt += direction * movespeed;
		vLookatPt += direction * movespeed;
	}

	void BackMove()
	{
		direction = vLookatPt - vEyePt;
		D3DXVec3Normalize(&direction, &direction);
		vEyePt -= direction * movespeed;
		vLookatPt -= direction * movespeed;
	}


	void Render()
	{
		D3DXMATRIXA16 matView;
		D3DXMatrixLookAtLH(&matView, &vEyePt, &vLookatPt, &vUpVec);
		m_pd3dDevice->SetTransform(D3DTS_VIEW, &matView);

		D3DXMATRIXA16 matProj;
		D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI / 4, 1.0f, 1.0f, 100.0f);
		m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj);
	}

	//�ش� ������ �ٶ󺸵��� 
	void LookAt(D3DXVECTOR3 pos)
	{
		//���� �ٶ󺸰��ִ� ������� �������̸� ���ؼ� �����ش�.
		//�� ���͸� ����ȭ�ϰ� �� ������ ������ ���ϸ� �ش� ���� cos@ ���� �ȴ�. �ش簪�� 
		vLookatPt = pos;


		/*D3DXVECTOR3 curLook;
		D3DXVECTOR3 destLook;
		D3DXVec3Normalize(&curLook, &vLookatPt);
		D3DXVec3Normalize(&destLook, &pos);*/

		

	}

	int GetMoveMode()
	{
		return movemode;
	}

	void SetMoveMode(int mode)
	{
		this->movemode = mode;
		vEyePt = First_vEyePt;
		vLookatPt = First_vLookatPt;
		vUpVec = First_vUpVec;
	}

private:
	LPDIRECT3DDEVICE9 m_pd3dDevice;

	D3DXVECTOR3 vEyePt;
	D3DXVECTOR3 vLookatPt;
	D3DXVECTOR3 vUpVec;

	D3DXVECTOR3 direction;

	float movespeed = 0.5f;
	float rotspeed = 0.4f;


	D3DXVECTOR3 First_vEyePt;
	D3DXVECTOR3 First_vLookatPt;
	D3DXVECTOR3 First_vUpVec;

	int movemode = 0;

	//GameObject* parent;

};


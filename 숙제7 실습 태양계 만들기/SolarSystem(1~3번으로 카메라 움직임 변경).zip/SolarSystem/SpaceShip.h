#pragma once
#include <Windows.h>
#include <mmsystem.h>
#include <d3dx9.h>
#include <strsafe.h>

#include "GameObject.h"


class Camera;

class SpaceShip:GameObject
{
public:
	

	SpaceShip(LPDIRECT3DDEVICE9 m_pd3dDevice, D3DXVECTOR3 pos, float width, float height, float depth, float speed)
	{
		D3DXCreateBox(m_pd3dDevice, width, height, depth, &m_pCubeMesh, NULL);
		this->pos = pos;
		//this->direction = D3DXVECTOR3(0, 0, 0) - pos;
		//D3DXVec3Normalize(&this->direction, &this->direction);
		this->m_pd3dDevice = m_pd3dDevice;
		this->speed = speed;
		rotspeed = 0.8f;
	}


	void FowardMove();
	void BackMove();

	/*void LeftMove()
	{
		D3DXVECTOR3 temp;
		D3DXMATRIXA16 matrot;
		D3DXMatrixRotationY(&matrot, (rot.y + 90.0f) * 3.14 / 180);
		D3DXVec3TransformNormal(&temp, &direction, &matrot);

		D3DXVec3Normalize(&temp, &temp);

		this->pos -= temp * speed;
	}

	void RightMove()
	{
		D3DXVECTOR3 temp;
		D3DXMATRIXA16 matrot;
		D3DXMatrixRotationY(&matrot, (rot.y + 90.0f) * 3.14 / 180);
		D3DXVec3TransformNormal(&temp, &direction, &matrot);

		D3DXVec3Normalize(&temp, &temp);
		this->pos += temp * speed;
	}*/

	void RightRot();
	void LeftRot();
	void UpRot();
	void DownRot();

	void VirRot(float fAngle);
	void HorRot(float fAngle);

	void SetRotation()
	{
		D3DXMATRIXA16 matworld;
		D3DXMATRIXA16 mattrans;
		D3DXMATRIXA16 matrot;

		D3DXMatrixIdentity(&matworld);

		D3DXMatrixRotationX(&matrot, rot.x * 3.14 / 180 );
		D3DXMatrixMultiply(&matworld, &matworld, &matrot);

		D3DXMatrixRotationY(&matrot, rot.y * 3.14 / 180 );
		D3DXMatrixMultiply(&matworld, &matworld, &matrot);
		
		D3DXMatrixRotationZ(&matrot, rot.z * 3.14 / 180 );
		D3DXMatrixMultiply(&matworld, &matworld, &matrot);

		D3DXMatrixTranslation(&mattrans, pos.x, pos.y, pos.z);
		D3DXMatrixMultiply(&matworld, &matworld, &mattrans);

		m_pd3dDevice->SetTransform(D3DTS_WORLD, &matworld);
	}

	//ȸ������ ���� ȸ����Ű�� ��ġ�� �̵�
	void Render()
	{
		SetRotation();

		m_pCubeMesh->DrawSubset(0);

	}

	//���ּ��� ī�Ӷ� �������ش�.
	void SetCamera(GameObject* camera, D3DXVECTOR3 pos);

private:
	LPDIRECT3DDEVICE9 m_pd3dDevice;
	//D3DXVECTOR3 pos;
	//D3DXVECTOR3 direction;
	//D3DXVECTOR3 rot;//�������� �Ҷ� ����������� ȸ����Ű�� ����
	LPD3DXMESH m_pCubeMesh;
	float speed;
	float rotspeed;

	
	GameObject* childCamera;

};

